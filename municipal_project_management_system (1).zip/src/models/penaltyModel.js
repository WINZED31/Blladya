
const penalties = [];

function addPenalty(penalty) {
    penalties.push(penalty);
}

module.exports = { addPenalty };
