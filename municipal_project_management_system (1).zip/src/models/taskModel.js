
const tasks = [];

function getTaskById(taskId) {
    return tasks.find(task => task.id === taskId);
}

function updateTaskStatus(task) {
    const index = tasks.findIndex(t => t.id === task.id);
    tasks[index] = task;
}

module.exports = { getTaskById, updateTaskStatus };
