
const users = [];

function getUserById(userId) {
    return users.find(user => user.id === userId);
}

module.exports = { getUserById };
