
function sendNotification(userId, message) {
    // إرسال إشعار للمستخدم
    console.log(`إشعار للمستخدم ${userId}: ${message}`);
}

module.exports = { sendNotification };
