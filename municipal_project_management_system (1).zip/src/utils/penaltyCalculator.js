
const { addPenalty } = require('../models/penaltyModel');
const { sendNotification } = require('./notifications');

function imposePenalty(taskId, userId, delayDuration) {
    let penalty = null;

    if (delayDuration > 7) {
        penalty = {
            type: 'fine',
            amount: 5000,
            description: `غرامة لتأخر المشروع عن الجدول الزمني (المهمة: ${taskId})`
        };
    } else if (delayDuration > 3) {
        penalty = {
            type: 'warning',
            amount: 0,
            description: `تحذير لتأخر المشروع عن الجدول الزمني (المهمة: ${taskId})`
        };
    }

    if (penalty) {
        addPenalty(penalty);
        sendNotification(userId, `تم فرض عقوبة عليك: ${penalty.description}`);
    }
}

module.exports = { imposePenalty };
