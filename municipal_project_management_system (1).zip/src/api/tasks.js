
const express = require('express');
const router = express.Router();
const { getTaskById, updateTaskStatus } = require('../models/taskModel');

// بدء مهمة جديدة
router.post('/start/:taskId', (req, res) => {
    const taskId = req.params.taskId;
    const task = getTaskById(taskId);
    const previousTask = getTaskById(task.previous_task_id);

    if (previousTask && previousTask.status !== 'completed') {
        return res.status(400).json({ message: "لا يمكن بدء المهمة الجديدة إلا بعد إتمام المهمة السابقة." });
    }

    task.status = "in_progress";
    updateTaskStatus(task);
    res.json({ message: "تم بدء المهمة بنجاح!" });
});

module.exports = router;
