
const express = require('express');
const router = express.Router();
const { imposePenalty } = require('../utils/penaltyCalculator');

// فرض عقوبة
router.post('/impose', (req, res) => {
    const { taskId, userId, delayDuration } = req.body;
    imposePenalty(taskId, userId, delayDuration);
    res.json({ message: "تم فرض العقوبة بنجاح!" });
});

module.exports = router;
